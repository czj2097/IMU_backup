#include "XDataArea.h"


CXDataArea::CXDataArea(void)
{
	for(int i = 0; i < 3; i++)
	{
		Quaternion.QArray[i]     = 0;
		DeltaQ[i]                = 0;
		EulerAngle.EulerArray[i] = 0;
		LinearAccleration[i]     = 0;
	}
}


CXDataArea::~CXDataArea(void)
{
}

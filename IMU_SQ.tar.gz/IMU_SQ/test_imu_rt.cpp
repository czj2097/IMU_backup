#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/mman.h>
#include <getopt.h>
#include <execinfo.h>
#include <native/task.h>
#include <native/timer.h>
#include "IMU.h"
#include "SerialPort.h"

#define LOG_PREFIX    "rt_serial_uprog: "
#define WTASK_PREFIX  "write_task: "
#define RTASK_PREFIX  "read_task : "

static CRTSerialPort rtPort;
static CIMU imu;
static const char* RTSER_FILE = "rtser0";


//static const int BAUDRATE = 115200;

// Notion:  this figure "10" is PARTICULARLY used for
// RTD CMA22M PC/104 computer for obtaining a higher
// speed baudrate. Make sure that the Xeno_16550A
// real-time driver's baudbase had been set as 491530, 
// thus actual divisor is 491530/10 = 49153, Hex number
// is 0xC001, which actually set the serial port running
// on the speed of 921600. See the CMA22M doc and the
// Xeno_16550A.c code.

static const int BAUDRATE = 10;
static int msgID;

#define STATE_FILE_OPENED         1
#define RD_TASK_CREATED           2
#define WR_TASK_CREATED           4
#define NUMBER_OF_LOOP            200000

static RTIME write_task_period_ns =   1000000llu;
static RT_TASK write_task;
static RT_TASK read_task;

static unsigned int currentState = 0;

void cleanup_all(void);
void read_task_proc(void *arg);
void write_task_proc(void *arg);
void catch_signal(int sig);
void warn_upon_switch(int sig, siginfo_t *si, void *context);

static const char *reason_str[] = {
    "undefined",
    "received signal",
    "invoked syscall",
    "triggered fault",
    "affected by priority inversion",
    "missing mlockall",
    "runaway thread",
};


int main(int argc, char* argv[]) {

	int ret = 0;
    struct sigaction sa;
    int err;
	printf(LOG_PREFIX "PRESS CTRL-C to EXIT\n");
	/* no memory-swapping for this programm */
	mlockall(MCL_CURRENT | MCL_FUTURE);
    sigemptyset(&sa.sa_mask);
    sa.sa_sigaction = warn_upon_switch;
    sa.sa_flags = SA_SIGINFO;
    sigaction(SIGDEBUG, &sa, NULL);
	signal(SIGTERM, catch_signal);
	signal(SIGINT, catch_signal);
    rt_print_auto_init(1);    
	rt_task_set_mode(0, T_WARNSW, NULL);

	/* open rtser0 */
	ret = rtPort.OpenPort("rtser0");
	if (ret) {
		printf(LOG_PREFIX "can't open %s\n", RTSER_FILE);
		goto error;
	}

	printf(LOG_PREFIX "rtser_file opened\n");
	currentState |= STATE_FILE_OPENED;

	/* writing write-config */
	ret = rtPort.SetBaudrate(BAUDRATE);
	if (ret) {
		printf(LOG_PREFIX "error while RTSER_RTIOC_SET_CONFIG, code %d\n",ret);
		goto error;
	}
	printf(LOG_PREFIX "serial-port-config written\n");

	ret = imu.Initialize(rtPort);
    if (ret < 0)
    {
        printf("Fail to init\n");
        goto error;
        
    }
	printf("Init finished!\n");

	/* create read_task */
	ret = rt_task_create(&read_task,"read_task",0,51,0);
	if (ret) {
		printf(LOG_PREFIX "failed to create read_task, code %d\n",ret);
		goto error;
	}
	currentState |= RD_TASK_CREATED;
	printf(LOG_PREFIX "read-task created\n");

	/* create write_task */
	ret = rt_task_create(&write_task,"write_task",0,50,0);
	if (ret) {
		printf(LOG_PREFIX "failed to create write_task, code %d\n",ret);
		goto error;
	}
	currentState |= WR_TASK_CREATED;
	printf(LOG_PREFIX "write-task created\n");

	/* start write_task */
	printf(LOG_PREFIX "starting write-task\n");
	ret = rt_task_start(&write_task,&write_task_proc,NULL);
	if (ret) {
		printf(LOG_PREFIX "failed to start write_task, code %d\n",ret);
		goto error;
	}

	/* start read_task */
	printf(LOG_PREFIX "starting read-task\n");
	ret = rt_task_start(&read_task,&read_task_proc,NULL);
	if (ret) {
		printf(LOG_PREFIX "failed to start read_task, code %d\n",ret);
		goto error;
	}
	printf(LOG_PREFIX "Loop Cylic Begins\n");
	pause();
	return 0;

error:
	cleanup_all();
	return ret;
}

void cleanup_all(void) {
	if (currentState & STATE_FILE_OPENED) {
		int ret = rtPort.ClosePort();
		if( ret == 0 )
			printf(LOG_PREFIX "close serial port\n");
		currentState &= ~STATE_FILE_OPENED;
	}
	if (currentState & WR_TASK_CREATED) {
		printf(LOG_PREFIX "delete write_task\n");
		rt_task_delete(&write_task);
		currentState &= ~WR_TASK_CREATED;
	}
	if (currentState & RD_TASK_CREATED) {
		printf(LOG_PREFIX "delete read_task\n");
		rt_task_delete(&read_task);
		currentState &= ~RD_TASK_CREATED;
	}
}

void catch_signal(int sig) {
	cleanup_all();
	printf(LOG_PREFIX "exit\n");
	return;
}

void write_task_proc(void *arg) {
	int ret;
	ssize_t sz = sizeof(RTIME);
	ssize_t written = 0;
	unsigned long overrun;
	int count = 0;

	ret = rt_task_set_periodic(NULL, TM_NOW, rt_timer_ns2ticks(write_task_period_ns));
	if (ret) {
		printf(WTASK_PREFIX "error while set periodic, code %d\n",ret);
		goto exit_write_task;
	}

	while (count++ < NUMBER_OF_LOOP) {
		ret = rt_task_wait_period(&overrun);
		if (ret) {
			printf(WTASK_PREFIX "error while rt_task_wait_period, code %d\n",ret);
            if (ret == -110)
            {
                printf(WTASK_PREFIX "Timeout, overrun tick = %ld\n", overrun);                
            }
			else
                goto exit_write_task;
		}
		//sz = sizeof(buf);
		//written = rt_dev_write(my_fd, &buf, sizeof(buf));
		/*
		printf(WTASK_PREFIX "rt_dev_write written=%d sz=%d\n", written, sz);
		if (written != sz ) {
			if (written < 0 ) {
				printf(WTASK_PREFIX "error while rt_dev_write, code %d\n",written);
			} else {
				printf(WTASK_PREFIX "only %d / %d byte transmitted\n",written, sz);
			}
			goto exit_write_task;
		}
		*/
	}
exit_write_task:
	printf(WTASK_PREFIX "exit\n");
}

void read_task_proc(void *arg) {
	int ret;
	//  RTIME irq_time   = 0;
	ssize_t sz = sizeof(RTIME);
	ssize_t red = 0;
	unsigned long overrun;
	int count = 0;

	ret = rt_task_set_periodic(NULL, TM_NOW, rt_timer_ns2ticks(write_task_period_ns));
	if (ret) {
		printf(RTASK_PREFIX "error while set periodic, code %d\n",ret);
		goto exit_read_task;
	}

	while (count++ < NUMBER_OF_LOOP) {
		ret = rt_task_wait_period(&overrun);
		if (ret) {
			printf(RTASK_PREFIX "error while rt_task_wait_period, code %d\n",ret);
            if (ret == -110)
            {
                printf(RTASK_PREFIX "Timeout, overrun tick = %ld\n", overrun);                
            }
			else
                goto exit_read_task;
		}
		// if you need a receive timestamp, you can get it this way
		//irq_time = rx_event.rxpend_timestamp;

		ret = imu.CycleProcess(rtPort);
		if(ret < 0){
			if (-ret == EAGAIN || -ret == EIO){
				printf("Again\n");
				continue;
			}
			else{
				printf(RTASK_PREFIX "Read Error Code %d\n", -ret);
				goto exit_read_task;
			}
		}
		//for(int i = 0; i < 4; i++)
		//	printf("DQ[%d] = %.3lf   ", i, imu.m_dataArea.DeltaQ[i]);
        //printf("\n");
   		//for(int i = 0; i < 3; i++)
		//	printf("Aw[%d] = %.3lf   ", i, imu.m_dataArea.AngularVelocity[i]);
		//printf("\n");
		//for(int i = 0; i < 3; i++)
		//	printf("Ac[%d] = %.3lf   ", i, imu.m_dataArea.LinearAccleration[i]);
		//printf("\n");
		/*printf("Roll = %.3lf  Pitch = %.3lf Yaw = %.3lf\n", 
			imu.m_dataArea.EulerAngle.EulerArray[0]/3.141592 * 180, 
			imu.m_dataArea.EulerAngle.EulerArray[1]/3.141592 * 180,
			imu.m_dataArea.EulerAngle.EulerArray[2]/3.141592 * 180);*/
	}
exit_read_task:
	cleanup_all();
	printf(RTASK_PREFIX "exit\n");
}


void warn_upon_switch(int sig, siginfo_t *si, void *context)
{
    unsigned int reason = si->si_value.sival_int;
    void *bt[32];
    int nentries;

    printf("\nSIGDEBUG received, reason %d: %s\n", reason,
	   reason <= SIGDEBUG_WATCHDOG ? reason_str[reason] : "<unknown>");
    /* Dump a backtrace of the frame which caused the switch to
       secondary mode: */
    nentries = backtrace(bt,sizeof(bt) / sizeof(bt[0]));
    backtrace_symbols_fd(bt,nentries,fileno(stdout));
}

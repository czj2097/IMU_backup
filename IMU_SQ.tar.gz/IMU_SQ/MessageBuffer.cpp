#include "MessageBuffer.h"

CMessageBuffer::CMessageBuffer(void)
{
	head = 0;
	rear = 0;
}


CMessageBuffer::~CMessageBuffer(void)
{
}

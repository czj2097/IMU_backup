#ifndef _SERIALPORT_H_
#define _SERIALPORT_H_

#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/mman.h>

class CSerialPort
{
private:
	int m_portID;
	struct timespec m_timeRequest;
	struct timespec m_timeRemaining;

public:
	CSerialPort(void);
	~CSerialPort(void);
	virtual int OpenPort(const char* portName);
	virtual int SetBaudrate(const int baudrate);
	virtual int ReadPort(unsigned char* bufferStartPointer);
	virtual int WritePort(const unsigned char* dataToSend, int dataLength);
	virtual int WaitInterval(int nanoscd);
	virtual int ClosePort();
};

#endif

#ifndef _MESSAGEBUFFER_H_
#define _MESSAGEBUFFER_H_
class CMessageBuffer
{
public:
	int head;
	int rear;
	unsigned char Data[8192];

	CMessageBuffer(void);
	~CMessageBuffer(void);
};

#endif


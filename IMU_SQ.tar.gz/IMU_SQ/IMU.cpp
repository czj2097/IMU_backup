#include "IMU.h"


CIMU::CIMU(void)
{
    m_waitTicks = DEFAULT_WAIT_TICKS;   // 500 ms
    m_state = IMU_MEASURING;
}


CIMU::~CIMU(void)
{
}

int CIMU::ReadDataToBuffer(CSerialPort& port)
{
	int bufferLength = m_receiveBuffer.rear - m_receiveBuffer.head;

	// put the old data to the beginning of the buffer
	for (int i = 0; i < bufferLength; i++)
	{
		m_receiveBuffer.Data[i] = m_receiveBuffer.Data[i + m_receiveBuffer.head];
	}

	// put the new data right after the old data 
	int readBytesCount = port.ReadPort(&m_receiveBuffer.Data[bufferLength]);
	if (readBytesCount < 0)
		return readBytesCount;
	//printf("Byte read: %d\n", readBytesCount);

	m_receiveBuffer.head = 0;
	m_receiveBuffer.rear = bufferLength + readBytesCount;
	return 0;
}

int CIMU::PickUpMessageFromBuffer()
{
	// find the message head
	for (int i = m_receiveBuffer.head; i < m_receiveBuffer.rear; i++)
	{
		// found the message head
		if (m_receiveBuffer.Data[i] == CXMessage::XPREAMBLE && 
			i + CXMessage::XBIDSHIFT < m_receiveBuffer.rear && 
			m_receiveBuffer.Data[i + CXMessage::XBIDSHIFT] == CXMessage::XBID)
		{
			//check whether the message head is completely received
			if (i + CXMessage::XHEADSTDLEN - 1 >= m_receiveBuffer.rear)
			{
				// no enough length for message head
				return NO_ENOUGH_HEAD_DATA;
			}

			int isExtend = (m_receiveBuffer.Data[i + CXMessage::XLENSHIFT] == CXMessage::XISEXT) ? 1 : 0;

			if (isExtend && i + CXMessage::XHEADEXTLEN >= m_receiveBuffer.rear)
			{
				// no enough length for extended head
				return NO_ENOUGH_EXT_HEAD_DATA;
			}

			// Get data length
			int dataLength = m_receiveMessage.RetriveLength(&(m_receiveBuffer.Data[i]), isExtend);

			// check if the data length is valid
			if (dataLength > CXMessage::XMAXDATALEN)
			{
				// invalid dataLength, continue to find a valid head
				continue;
			}

			//check whether the message is completely received
			int dataStartIndex = isExtend ? (i + CXMessage::XHEADEXTLEN) : ( i + CXMessage::XHEADSTDLEN );

			if ( dataLength + dataStartIndex >= m_receiveBuffer.rear) // include the checksum
			{
				// not enough data can be read, continue to find a valid head
				continue;
			}

			//pick out the message
			m_receiveMessage.PickUp(&(m_receiveBuffer.Data[i]), isExtend, dataLength);

			if (m_receiveMessage.isCheckSumOK())
			{
				// successfully pick up a valid message, update buffer.head to remove the data which has been read
				m_receiveBuffer.head = dataLength + dataStartIndex + 1;
				return 0;
			}

			// not a valid message, continue to next head
			m_receiveMessage.Clear();
		}
	}
	// no valid message found
	return NO_VALID_MESSAGE;
}

int CIMU::UpdateGyroData()
{
	int pkgHeadPos = 0;
	int dataLength = m_receiveMessage.GetDataLength();

	while (1)
	{
		if (pkgHeadPos + CXPackage::XPACKAGEHEADLEN > dataLength || 
			(int)m_receiveMessage.m_messageData[pkgHeadPos + CXPackage::XPACKAGELENSHIFT] + CXPackage::XPACKAGEHEADLEN > dataLength){
				// no enough data left for a new package			
				break;
		}

		m_package.RetrivePackage(&(m_receiveMessage.m_messageData[pkgHeadPos]));

		// Update Gyro data
		m_package.UpdateGyroData(m_dataArea);

		pkgHeadPos += (int)m_receiveMessage.m_messageData[pkgHeadPos + CXPackage::XPACKAGELENSHIFT] + CXPackage::XPACKAGEHEADLEN;
	}
	return 0;
}

int CIMU::CycleProcess(CSerialPort& port)
{
	int msgID;
    m_waitACK = -1;
    
	int ret = ReadDataToBuffer(port);
  	//if ( ret < 0 )
	//	return ret;

	while(PickUpMessageFromBuffer() == 0)
	{
		msgID = m_receiveMessage.GetMessageID();
		//printf("Message Received: ID = %d\n", msgID);
		switch (msgID)
		{
		case CXMessage::MID_MTDATA2:
			UpdateGyroData();
			break;
		case CXMessage::MID_GOTOMEASURE_ACK:
		case CXMessage::MID_SETBAUDRATE_ACK:
		case CXMessage::MID_GOTOCONFIG_ACK:
		case CXMessage::MID_RESET_ACK:		
		case CXMessage::MID_SETOUTPUTCONFIG_ACK:
			m_waitACK = msgID;

			//printf("MessageAcked, %d\n", msgID);
			break;
		default:
			printf("Unknown Message Received: Length = %d\n", m_receiveMessage.GetDataLength());
			for(int i = 0; i < m_receiveMessage.GetDataLength(); i++)
				printf("0x%2x  ", m_receiveMessage.m_messageData[i]);
			printf("\n");
		}
	}
    
    UpdateIMUState(port);
	return 0;
}

int CIMU::Initialize(CSerialPort& port)
{
	return ConfigureDevice(port);
}

int CIMU::ResetDevice(CSerialPort& port)
{
	m_sendMessage.MessageReset();
	return SendMessage(port);
}

int CIMU::ConfigureDevice(CSerialPort& port)
{
    m_state = IMU_NO_CONFIG;
    m_waitTicks = DEFAULT_WAIT_TICKS;

    return 0;
}

int CIMU::GoToMeasure( CSerialPort& port )
{
	m_sendMessage.MessageGotoMeasure();
	return SendMessage(port);
}

int CIMU::SendMessage( CSerialPort&port)
{
	m_sendMessage.BuildBuffer(m_sendBuffer);
	int rc = -4;
	int tryTimes = 5;
	while(rc < 0 && tryTimes > 0){
		rc = port.WritePort(m_sendBuffer.Data, m_sendMessage.GetTotalLength()); // including CheckSum
		printf("Write Serial: %d\n", rc);
		tryTimes--;
	}
	return rc;
}

int CIMU::WaitForAck(CSerialPort& port, CXMessage::XMESSAGE_ID ackID)
{
	m_waitACK = -1;
	int tryTime = 5;
	int timeInterval = 1000 * 1000 * 200;   // 200 ms
	while(m_waitACK != ackID && tryTime > 0){
		port.WaitInterval(timeInterval);
		CycleProcess(port);
		tryTime--;
	}
	return (tryTime > 0) ? 0 : -1;
}

void CIMU::GetData(CXDataArea *p_destData)
{
    *p_destData = m_dataArea; // just use the copy constructor
}

int CIMU::UpdateIMUState(CSerialPort& port)
{
    int rc;

    switch (m_state)
    {
    case IMU_NO_CONFIG:
        printf("Goto Config!\n");
        m_sendMessage.MessageGotoConfig();
        rc = SendMessage(port);
        if (rc < 0){
            printf("Fail to send GOTO_CONFIG msg\n");
            m_state = IMU_FAULT;
        }
        else
            m_state = IMU_GOTO_CONFIG;
        break;
    case IMU_GOTO_CONFIG:
        if (m_waitACK == CXMessage::MID_GOTOCONFIG_ACK){
            printf("Set Output mode\n");
            m_sendMessage.MessageSetOutputConfig(DEFAULT_OUTPUT_CONFIG);
            rc = SendMessage(port);
            if (rc < 0){
                printf("Fail to send SET_OUTPUT msg\n");
                m_state = IMU_FAULT;
            }
            else
                m_state = IMU_INCONFIG;
        }
            
        break;
    case IMU_INCONFIG:
        if (m_waitACK == CXMessage::MID_SETOUTPUTCONFIG_ACK){
            printf("Goto Measure\n");
            m_sendMessage.MessageGotoMeasure();
            rc = SendMessage(port);
            if (rc < 0){
                printf("Fail to send GOTO_MEASURE msg\n"); 
                m_state = IMU_FAULT;
            }
            else
                m_state = IMU_GOTO_MEASURE;
        }
        
        break;
    case IMU_GOTO_MEASURE:
        if (m_waitACK == CXMessage::MID_GOTOMEASURE_ACK){
            printf("Measuring\n");
            m_state = IMU_MEASURING;
        }
        break;
    case IMU_MEASURING:
        break;
    case IMU_FAULT:
        break;
    default:
        break;
    }
}

const int CIMU::DEFAULT_WAIT_TICKS = 500;

const int CIMU::DEFAULT_OUTPUT_BAUDRATE = 115200;

const int CIMU::DEFAULT_SAMPLE_FREQUENCY = 100;

const CXOutputConfig CIMU::DEFAULT_OUTPUT_CONFIG = {
	0,   // not contain time
	1,   // contains Quaternion
	1,   // contains DeltaQ
	1,   // contains LinearAcc
	400  // SampleFrequency
};



#include <cstdio>
#include <cstdlib>
#include "IMU.h"
#include "SerialPort.h"

#include <time.h>

using namespace std;

void WaitForInterval(struct timespec *req, struct timespec *rem);

int main(int argc, char** argv)
{
	int i;
	CIMU imu;
	CSerialPort port;

	struct timespec req;
	struct timespec rem;

	// Note: the maximum speed can use for PC104 non-RT
	// serial port driver is 115200, limiting the sample
	// rate to 200Hz. For higher speed, please use the 
	// RT version program.
	int baudrate = 921600;

	req.tv_sec = 0;
	req.tv_nsec = 1000 * 1000;
	int msgID;
	int count = 0;
	char portName[20] = "/dev/ttyUSB0";

	int rc = port.OpenPort(portName);
	if(rc != 0)
	{
		printf("Open Port Failed!\n");
		return 0;
	}

	printf("Open Port %s!\n", portName);

	rc = port.SetBaudrate(baudrate);
	if(rc != 0)
	{
		printf("Set Baudrate Failed!\n");
		port.ClosePort();
		return 0;
	}
	printf("Baudrate set as %d!\n", baudrate);

	imu.Initialize(port);

	printf("Init finished!\n");

	while(count++ < 20000)
	{
		WaitForInterval(&req, &rem);

		imu.CycleProcess(port);		

		for(int i = 0; i < 4; i++)
			printf("DQ[%d] = %.3lf   ", i, imu.m_dataArea.DeltaQ[i]);
		printf("\n");
		for(int i = 0; i < 3; i++)
			printf("Ac[%d] = %.3lf   ", i, imu.m_dataArea.LinearAccleration[i]);
		printf("\n");
		printf("Roll = %.3lf  Pitch = %.3lf Yaw = %.3lf\n", 
			imu.m_dataArea.EulerAngle.EulerArray[0]/3.141592 * 180, 
			imu.m_dataArea.EulerAngle.EulerArray[1]/3.141592 * 180,
			imu.m_dataArea.EulerAngle.EulerArray[2]/3.141592 * 180);
		
	}

	port.ClosePort();

	return 0;
}

void WaitForInterval(struct timespec *req, struct timespec *rem)
{
	nanosleep(req, rem);
	return;
}

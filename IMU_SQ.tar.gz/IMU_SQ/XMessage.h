#ifndef _XMESSAGE_H_
#define _XMESSAGE_H_


#include "XDataArea.h"
#include "MessageBuffer.h"
#include <cstdio>

struct CXQuaternion
{
	float Quaternion[4];
};

struct CXDeltaQ
{
	float DeltaQ[4];
};

struct CXAccel
{
	float Accel[3];
};

struct CXOutputConfig
{
	int ContainsTime;
	int ContainsQuaternion;
	int ContainsDeltaQ;
	int ContainsLinearAcc;
	int  SampleFreq;
};

struct CXOutputConfigData
{
	char FirstIdentifier;
	char SecondIdentifier;
	short Frequency;
};

class CXMessage
{
public:
	static const int XPREAMBLE = 0xFA;
	static const int XBID      = 0xFF;
	static const int XISEXT    = 0xFF;
	static const int XBIDSHIFT = 1;
	static const int XMIDSHIFT = 2;
	static const int XLENSHIFT = 3;
	static const int XEXLENSHIFT = 4;

	static const int XHEADSTDLEN;
	static const int XHEADEXTLEN;
	static const int XMAXHEADLEN = 6;
	static const int XMAXDATALEN = 2048;
	static const int XMAXSAMPLERATE = 400;
	static const int XDEFSAMPLERATE = 100;

	enum XMESSAGE_ID
	{
		MID_GOTOMEASURE     = 16,
		MID_GOTOMEASURE_ACK = 17,
		MID_SETBAUDRATE     = 24,
		MID_SETBAUDRATE_ACK = 25,
		MID_GOTOCONFIG      = 48,
		MID_GOTOCONFIG_ACK  = 49,
		MID_MTDATA2         = 54,
		MID_WAKEUP          = 62,
		MID_RESET           = 64,
		MID_RESET_ACK       = 65,		
		MID_SETOUTPUTCONFIG = 192,
		MID_SETOUTPUTCONFIG_ACK = 193
	};

	CXMessage(void);
	~CXMessage(void);
	int isValid();;
	int GetMessageID() const;
	int GetDataLength() const;
	int GetTotalLength() const;
	int Getchecksum() const;

	int RetriveLength( unsigned char* headStartPoint, int isExtend );
	void Clear();
	void PickUp( unsigned char* messageStartPoint, int isExtend, int dataLength );
	bool isCheckSumOK();
	void MessageReset();
	void MessageGotoConfig();
	void MessageSetBaud( const int baudrate );
	void MessageSetOutputConfig( const CXOutputConfig& outputConfig );
	void MessageGotoMeasure();
	void BuildBuffer( CMessageBuffer& buffer );
	
	unsigned char m_messageHead[XMAXHEADLEN + 1];
	unsigned char m_messageData[XMAXDATALEN + 1];

private:
	int m_id;
	int m_dataLength;
	int m_checksum;
	int m_isExtend;
	int m_headLength;
	bool m_isCheckSumOK;
	int CalculateCheckSum( int headLength, int dataLength );
};

class CXPackage
{
public:
	static const int XPACKAGEHEADLEN = 3;
	static const int XPACKAGEDATAMAXLEN = 256;
	static const int XPACKAGEIDSHIFT = 0;
	static const int XPACKAGELENSHIFT = 2;

	enum XPACKAGE_ID
	{
		XQUATERNION   = 0x201,
		XEULERANGLE   = 0x203,
		XUTCTIME      = 0x101,
		XDELTAQ       = 0x803,
		XRATEOFTURN   = 0x802,
		XACCELERATION = 0x402
	};

	CXPackage(void);
	~CXPackage(void);
	void RetrivePackage(const unsigned char* data);
	int GetPackageID() const;
	int GetPackageLength() const;
	void UpdateGyroData(CXDataArea& dataArea);
	int EndianConvert32(const int* pNumber);
	unsigned char m_packageData[XPACKAGEDATAMAXLEN];
private:	
	int m_packageID;
	int m_packageDataLength;
	struct CXQuaternion* m_pQuaternionDataStruct;
	struct CXDeltaQ* m_pDeltaQDataStruct;
	struct CXAccel*  m_pAccelDataStruct;
};


#endif

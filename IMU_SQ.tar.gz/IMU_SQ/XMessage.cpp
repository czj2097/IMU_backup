#include "XMessage.h"

const int CXMessage::XHEADSTDLEN = 4;
const int CXMessage::XHEADEXTLEN = 6;

CXMessage::CXMessage(void)
{
}

CXMessage::~CXMessage(void)
{
}

int CXMessage::RetriveLength( unsigned char* headStartPoint, int isExtend )
{
	if (isExtend)
	{
		return headStartPoint[XEXLENSHIFT] * 0x100 + headStartPoint[XEXLENSHIFT+1];
	}
	return headStartPoint[XLENSHIFT];
}

void CXMessage::Clear()
{
	m_isCheckSumOK = false;
	return;
}

void CXMessage::PickUp( unsigned char* messageStartPoint, int isExtend, int dataLength )
{
	m_id = (int)messageStartPoint[XMIDSHIFT];
	m_dataLength = dataLength;
	m_isExtend = isExtend;
	m_headLength = isExtend ? XHEADEXTLEN : XHEADSTDLEN;
	//m_headLength = isExtend ? 6 : 4;
	m_checksum = (int)messageStartPoint[m_headLength + m_dataLength];

	int sum = 0;

	// copy head information
	for (int i = 0; i < m_headLength; i++)
	{
		m_messageHead[i] = messageStartPoint[i];
		if (i != 0) // get rid of PREAMBLE
			sum += (int)m_messageHead[i];
	}

	// copy body information
	for (int i = 0; i < m_dataLength; i++)
	{
		m_messageData[i] = messageStartPoint[m_headLength + i];
		sum += m_messageData[i];
	}

	sum += m_checksum;

	//  If all message bytes excluding the preamble are 
	//  summed and the lower byte value of the result equals zero, the message is valid
	if (sum % 0x100 == 0)
		m_isCheckSumOK = true;
	else
		m_isCheckSumOK = false;
}

bool CXMessage::isCheckSumOK()
{
	return m_isCheckSumOK;
}

int CXMessage::Getchecksum() const
{
	return m_checksum;
}

int CXMessage::GetDataLength() const
{
	return m_dataLength;
}

int CXMessage::GetMessageID() const
{
	return m_id;
}

int CXMessage::isValid()
{
	return 0;
}

int CXMessage::GetTotalLength() const
{
	return m_headLength + m_dataLength + 1; // including the Checksum
}

void CXMessage::MessageReset()
{
	m_headLength = XHEADSTDLEN;
	m_id = MID_RESET;
	m_dataLength = 0;
	m_messageHead[0] = XPREAMBLE;
	m_messageHead[XBIDSHIFT] = XBID;
	m_messageHead[XMIDSHIFT] = (unsigned char)m_id;
	m_messageHead[XLENSHIFT] = (unsigned char)m_dataLength;
	
	m_checksum = CalculateCheckSum(m_headLength, m_dataLength);
	return;
}

void CXMessage::MessageGotoConfig()
{
	m_headLength = XHEADSTDLEN;
	m_id = MID_GOTOCONFIG;
	m_dataLength = 0;
	m_messageHead[0] = XPREAMBLE;
	m_messageHead[XBIDSHIFT] = XBID;
	m_messageHead[XMIDSHIFT] = (unsigned char)m_id;
	m_messageHead[XLENSHIFT] = (unsigned char)m_dataLength;

	m_checksum = CalculateCheckSum(m_headLength, m_dataLength);
	return;
}

void CXMessage::MessageSetBaud( const int baudrate )
{
	m_headLength = XHEADSTDLEN;
	m_id = MID_SETBAUDRATE;
	m_dataLength = 1;
	m_messageHead[0] = XPREAMBLE;
	m_messageHead[XBIDSHIFT] = XBID;
	m_messageHead[XMIDSHIFT] = (unsigned char)m_id;
	m_messageHead[XLENSHIFT] = (unsigned char)m_dataLength;

	int baudRateID;
	switch (baudrate)
	{
	case 4800:
		baudRateID = 11;
		break;
	case 9600:
		baudRateID = 9;
		break;
	case 14400:
		baudRateID = 8;
		break;
	case 19200:
		baudRateID = 7;
		break;
	case 28800:
		baudRateID = 6;
		break;
	case 38400:
		baudRateID = 5;
		break;
	case 57600:
		baudRateID = 4;
		break;
	case 115200:
		baudRateID = 2;
		break;
	case 230400:
		baudRateID = 1;
		break;
	case 460800:
		baudRateID = 0;
		break;
	case 921600:
		baudRateID = 128;
		break;
	default:
		baudRateID = 2;   // default baudrate is 115200
	}
	m_messageData[0] = (unsigned char)baudRateID;

	m_checksum = CalculateCheckSum(m_headLength, m_dataLength);
	return;
}

void CXMessage::MessageSetOutputConfig( const CXOutputConfig& outputConfig )
{
	m_headLength = XHEADSTDLEN;
	m_id = MID_SETOUTPUTCONFIG;
	int sampleFreq = outputConfig.SampleFreq;

	int nDataRequest = 
		outputConfig.ContainsDeltaQ + 
		outputConfig.ContainsLinearAcc + 
		outputConfig.ContainsQuaternion + 
		outputConfig.ContainsTime;
	m_dataLength = 4 * nDataRequest;
	m_messageHead[0] = XPREAMBLE;
	m_messageHead[XBIDSHIFT] = XBID;
	m_messageHead[XMIDSHIFT] = (unsigned char)m_id;
	m_messageHead[XLENSHIFT] = (unsigned char)m_dataLength;

	if (outputConfig.SampleFreq > XMAXSAMPLERATE)
	{
		sampleFreq = XDEFSAMPLERATE;
	}
	// adjust Endianess
	sampleFreq = ((sampleFreq >> 8)&0xFF)|((sampleFreq << 8)&0xFF00);

	CXOutputConfigData configData;
	int nIter = 0;
	unsigned char *pTemp;
	if (outputConfig.ContainsTime)
	{
		configData.FirstIdentifier = 0x10;
		configData.SecondIdentifier = 0x10;


		configData.Frequency = sampleFreq; 
		pTemp = (unsigned char *)&configData;
		for (int i = 0; i < sizeof(configData); i++)
		{
			m_messageData[nIter] = *(pTemp + i);
			nIter++;
		}
	}

	if (outputConfig.ContainsQuaternion)
	{
		configData.FirstIdentifier = 0x20;
		configData.SecondIdentifier = 0x10;
		configData.Frequency = sampleFreq;
		pTemp = (unsigned char *)&configData;
		for (int i = 0; i < sizeof(configData); i++)
		{
			m_messageData[nIter] = *(pTemp + i);
			nIter++;
		}
	}

	if (outputConfig.ContainsDeltaQ)
	{
		configData.FirstIdentifier = 0x80;
		configData.SecondIdentifier = 0x30;
		configData.Frequency = sampleFreq;
		pTemp = (unsigned char *)&configData;
		for (int i = 0; i < sizeof(configData); i++)
		{
			m_messageData[nIter] = *(pTemp + i);
			nIter++;
		}
	}

	if (outputConfig.ContainsLinearAcc)
	{
		configData.FirstIdentifier = 0x40;
		configData.SecondIdentifier = 0x20;
		configData.Frequency = sampleFreq;
		pTemp = (unsigned char *)&configData;
		for (int i = 0; i < sizeof(configData); i++)
		{
			m_messageData[nIter] = *(pTemp + i);
			nIter++;
		}
	}

	m_checksum = CalculateCheckSum(m_headLength, m_dataLength);
	return;
	return;
}

void CXMessage::MessageGotoMeasure()
{
	m_headLength = XHEADSTDLEN;
	m_id = MID_GOTOMEASURE;
	m_dataLength = 0;
	m_messageHead[0] = XPREAMBLE;
	m_messageHead[XBIDSHIFT] = XBID;
	m_messageHead[XMIDSHIFT] = (unsigned char)m_id;
	m_messageHead[XLENSHIFT] = (unsigned char)m_dataLength;

	m_checksum = CalculateCheckSum(m_headLength, m_dataLength);
	return;
}

void CXMessage::BuildBuffer( CMessageBuffer& buffer )
{
	for (int i = 0; i < m_headLength; i++)
	{
		buffer.Data[i] = m_messageHead[i];
	}
	for (int i = 0; i < m_dataLength; i++)
	{
		buffer.Data[i + m_headLength] = m_messageData[i];
	}
	buffer.Data[m_headLength + m_dataLength] = (unsigned char)m_checksum;
	return;
}

int CXMessage::CalculateCheckSum( int headLength, int dataLength )
{
	int sum = 0;
	for (int i = 1; i < headLength; i++)
	{
		sum += m_messageHead[i];
	}
	for (int i = 0; i < dataLength; i++)
	{
		sum += m_messageData[i];
	}
	return 0x100 - (sum % 0x100);
}



//////////////////////////////////////////////////////////////////////////////////////////
CXPackage::CXPackage(void)
{
}

CXPackage::~CXPackage(void)
{
}

int CXPackage::GetPackageID() const
{
	return m_packageID;
}

int CXPackage::GetPackageLength() const
{
	return m_packageDataLength;
}

void CXPackage::RetrivePackage(const unsigned char* data)
{
	m_packageID = (int)data[XPACKAGEIDSHIFT] * 0x100 + (int)data[XPACKAGEIDSHIFT + 1];
	m_packageDataLength = (int)data[CXPackage::XPACKAGELENSHIFT];
	for (int i = 0; i < m_packageDataLength; i++)
	{
		m_packageData[i] = data[XPACKAGEHEADLEN + i];
	}
}

void CXPackage::UpdateGyroData(CXDataArea& dataArea)
{
	int tmpInt;
	float* ptmpFloat;
	switch (m_packageID >> 4)
	{
	// convert raw byte array to corresponding data structure
	case XQUATERNION:
		m_pQuaternionDataStruct = (struct CXQuaternion*)m_packageData;
		for(int i = 0; i < 4; i++){
			// re-adjust endianness if needed on target platform
			tmpInt = EndianConvert32((int *)(&m_pQuaternionDataStruct->Quaternion[i]));
			ptmpFloat = (float *)&tmpInt;
			dataArea.Quaternion.QArray[i] = *ptmpFloat;
		}
		dataArea.ConvertQuaternion2Euler();
		break;
	case XDELTAQ:
		m_pDeltaQDataStruct = (struct CXDeltaQ*)m_packageData;
		for(int i = 0; i < 4; i++){
			// re-adjust endianness if needed on target platform
			tmpInt = EndianConvert32((int *)(&m_pDeltaQDataStruct->DeltaQ[i]));
			ptmpFloat = (float *)&tmpInt;
			dataArea.DeltaQ[i] = *ptmpFloat;
		}
        dataArea.ConvertDeltaQ2AngularVelocity();
		break;
	case XACCELERATION:
		m_pAccelDataStruct = (struct CXAccel*)m_packageData;
		for(int i = 0; i < 3; i++){
			// re-adjust endianness if needed on target platform
			tmpInt = EndianConvert32((int *)(&m_pAccelDataStruct->Accel[i]));
			ptmpFloat = (float *)&tmpInt;
			dataArea.LinearAccleration[i] = *ptmpFloat;
		}
		break;
	default:
		printf("Unknown pakage: %d\n",m_packageID);
	}
}

int CXPackage::EndianConvert32(const int* pNumber)
{
	int number = *pNumber;
	return ((number >> 24) & 0xFF) |
           ((number >> 8)  & 0xFF00) |
           ((number << 8)  & 0xFF0000) |
           ((number << 24) & 0xFF000000);
}

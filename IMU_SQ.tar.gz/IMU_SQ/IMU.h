#ifndef _IMU_H_
#define _IMU_H_

#include <cstdio>
#include "MessageBuffer.h"
#include "SerialPort.h"
#include "XMessage.h"
#include "XDataArea.h"

class CIMU
{
public:
    enum IMUSTATE
    {
        IMU_NO_CONFIG      = 0,
        IMU_GOTO_CONFIG    = 1,
        IMU_INCONFIG       = 3,
        IMU_GOTO_MEASURE   = 4,
        IMU_MEASURING      = 5,
        IMU_FAULT          = 6
    };
    
	enum ERRCODE
	{
		NO_ENOUGH_HEAD_DATA = -1,
		NO_ENOUGH_EXT_HEAD_DATA = -2,
		NO_VALID_MESSAGE = -4
	};

	static const int DEFAULT_OUTPUT_BAUDRATE;
    static const int DEFAULT_WAIT_TICKS;
	static const int DEFAULT_SAMPLE_FREQUENCY;
	static const CXOutputConfig DEFAULT_OUTPUT_CONFIG;

	CIMU(void);
	~CIMU(void);
	int CycleProcess(CSerialPort& port);
	int ReadDataToBuffer(CSerialPort& port);
	int PickUpMessageFromBuffer();
	int UpdateGyroData();
    int UpdateIMUState(CSerialPort& port);

	int Initialize(CSerialPort& port);

	int ResetDevice(CSerialPort& port);
	int GoToMeasure(CSerialPort& port);
	int ConfigureDevice(CSerialPort& port);

	int SendMessage(CSerialPort&port);
	int WaitForAck(CSerialPort& port, CXMessage::XMESSAGE_ID ackID);

    void GetData(CXDataArea *p_destData);

	CXDataArea m_dataArea;

private:
	int m_waitACK;
    IMUSTATE m_state;
    int m_waitTicks;
	CMessageBuffer m_receiveBuffer;
	CMessageBuffer m_sendBuffer;
	CXMessage m_receiveMessage;
	CXMessage m_sendMessage;
	CXPackage m_package;

};

#endif


#ifndef _XDATAAREA_H_
#define _XDATAAREA_H_

#include <cmath>

using namespace std;

class CXDataArea
{
public:

	union {
		double QArray[4];
		struct
		{
			double w;
			double x;
			double y;
			double z;
		} QStruct;
	} Quaternion;
	union {
		double EulerArray[3];
		struct
		{
			double roll;
			double pitch;
			double yaw;
		} EulerStruct;
	} EulerAngle;
	double DeltaQ[4];
    double AngularVelocity[3];
	double LinearAccleration[3];
	CXDataArea(void);
	~CXDataArea(void);

	// after updating, related data should be synchronized, e.g. Quaternion and EulerAngle
	inline void ConvertQuaternion2Euler(void)
	{
		EulerAngle.EulerStruct.roll = 
			atan2(2 * ( Quaternion.QStruct.w * Quaternion.QStruct.x + Quaternion.QStruct.y * Quaternion.QStruct.z), 
			  1 - 2 * ( Quaternion.QStruct.x * Quaternion.QStruct.x + Quaternion.QStruct.y * Quaternion.QStruct.y));
		EulerAngle.EulerStruct.pitch = 
			asin( 2 * ( Quaternion.QStruct.w * Quaternion.QStruct.y - Quaternion.QStruct.z * Quaternion.QStruct.x));
		EulerAngle.EulerStruct.yaw  =
			atan2(2 * ( Quaternion.QStruct.w * Quaternion.QStruct.z + Quaternion.QStruct.y * Quaternion.QStruct.x), 
			  1 - 2 * ( Quaternion.QStruct.z * Quaternion.QStruct.z + Quaternion.QStruct.y * Quaternion.QStruct.y));
	};

    // The result is related to the current orientation
    inline void ConvertDeltaQ2AngularVelocity(void)
    {
        AngularVelocity[0] = DeltaQ[1] / 0.0025 * 2.0;
        AngularVelocity[1] = DeltaQ[2] / 0.0025 * 2.0;
        AngularVelocity[2] = DeltaQ[3] / 0.0025 * 2.0;        
    }
	
};

#endif

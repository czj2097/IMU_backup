#include "SerialPort.h"

using namespace std;

CSerialPort::CSerialPort(void)
{
}

CSerialPort::~CSerialPort(void)
{
}

int CSerialPort::OpenPort(const char* portName)
{
	m_portID = open(portName, O_RDWR);
	if (-1 == m_portID)
		return -1;
	return 0;
}

int CSerialPort::ClosePort()
{
	close(m_portID);
	return 0;
}

int CSerialPort::SetBaudrate(const int baudrate)
{
	struct termios options;
	tcgetattr(m_portID, &options);
	cfsetispeed(&options, baudrate);
	cfsetospeed(&options, baudrate);
	int rc = tcsetattr(m_portID, TCSANOW, &options);
	return rc;
}

int CSerialPort::ReadPort(unsigned char* bufferStartPointer)
{
	int Len = 1024;
	return read(m_portID, bufferStartPointer, Len);
}

int CSerialPort::WritePort(const unsigned char* dataToSend, int dataLength)
{
	return write(m_portID, dataToSend, dataLength);
}

int CSerialPort::WaitInterval( int nanoscd )
{
	m_timeRequest.tv_sec = nanoscd / 1000000000l;
	m_timeRequest.tv_nsec = nanoscd % 1000000000l;
	return nanosleep(&m_timeRequest, &m_timeRemaining);
}


#ifndef XSENUMERATEUSBDEVICES_H
#define XSENUMERATEUSBDEVICES_H

#include "xsens/xsportinfolist.h"

bool xsEnumerateUsbDevices(XsPortInfoList& ports);

#endif // file guard